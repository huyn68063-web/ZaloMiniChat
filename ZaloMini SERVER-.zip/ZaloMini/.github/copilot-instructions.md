# Copilot Instructions

## Project Guidelines
- Project preference: use DataContractJsonSerializer or Newtonsoft.Json for JSON serialization and implement Packet protocol with 4-byte length-prefix framing for client-server communication on .NET Framework 4.7.2.
- When handling `PacketType.Message`, the server must forward the packet to all connected clients by iterating over `_clients` and calling `SendPacketToClientAsync` for each client except the sender.
- Remove demo offline 'Accounts' storage; login must use `NetworkClient` and `PacketType.Login`.
- Replace undefined `CenterOnCurrentScreen()` with standard WinForms centering using `Screen.FromControl` or `WorkingArea` centering.