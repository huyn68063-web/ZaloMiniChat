using System;
using System.Collections.Concurrent;
using System.IO;

namespace ZaloMini.Server.Services
{
    public class FileService : IDisposable
    {
        // Map RequestId -> FileStream
        private readonly ConcurrentDictionary<string, FileStream> _streams =
            new ConcurrentDictionary<string, FileStream>(StringComparer.OrdinalIgnoreCase);

        // Thư mục lưu file (Downloads)
        private readonly string _downloadDir;

        public FileService(string downloadDir = null)
        {
            _downloadDir = downloadDir ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads", "ZaloServer");
            Directory.CreateDirectory(_downloadDir);
        }

        // Tạo FileStream mới khi nhận FILE_META
        public void CreateFileStream(string requestId, string fileName)
        {
            var path = Path.Combine(_downloadDir, SanitizeFileName(fileName));
            var fs = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.None, bufferSize: 1024 * 64, useAsync: true);
            _streams[requestId] = fs;
        }

        // Ghi chunk bytes vào stream đang mở
        public void WriteChunk(string requestId, byte[] data)
        {
            if (_streams.TryGetValue(requestId, out var fs))
            {
                // Ghi trực tiếp xuống đĩa
                fs.Write(data, 0, data.Length);
                fs.Flush(); // đảm bảo dữ liệu đã xuống đĩa trước khi gửi ACK (Stop-and-Wait)
            }
            else
            {
                throw new InvalidOperationException("No file stream for requestId " + requestId);
            }
        }

        public void CloseFileStream(string requestId)
        {
            if (_streams.TryRemove(requestId, out var fs))
            {
                try { fs.Flush(); } catch { }
                try { fs.Close(); } catch { }
                try { fs.Dispose(); } catch { }
            }
        }

        public void DisposeAll()
        {
            foreach (var kv in _streams)
            {
                try { kv.Value.Flush(); } catch { }
                try { kv.Value.Close(); } catch { }
                try { kv.Value.Dispose(); } catch { }
            }
            _streams.Clear();
        }

        private string SanitizeFileName(string name)
        {
            foreach (var c in Path.GetInvalidFileNameChars())
                name = name.Replace(c, '_');
            return name;
        }

        public void Dispose()
        {
            DisposeAll();
        }
    }
}