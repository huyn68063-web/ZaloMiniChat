using System;
using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using ZaloMini.Server.Services;
using ZaloMini.Client.Models;

namespace ZaloMini.Server
{
    public class ZaloServer
    {
        private readonly TcpListener _listener;
        private readonly CancellationTokenSource _cts = new CancellationTokenSource();

        // Online clients keyed by client id (e.g., username)
        private readonly ConcurrentDictionary<string, ClientHandler> _onlineClients =
            new ConcurrentDictionary<string, ClientHandler>();

        public AuthService AuthService { get; }
        public FileService FileService { get; }

        public ZaloServer(int port)
        {
            _listener = new TcpListener(IPAddress.Any, port);
            AuthService = new AuthService();
            FileService = new FileService();
        }

        public async Task StartAsync()
        {
            _listener.Start();
            Console.WriteLine($"Server started on {_listener.LocalEndpoint}.");

            try
            {
                while (!_cts.Token.IsCancellationRequested)
                {
                    var tcpClient = await _listener.AcceptTcpClientAsync();
                    var handler = new ClientHandler(tcpClient, this);
                    _ = handler.RunAsync(); // fire-and-forget
                }
            }
            catch (ObjectDisposedException) { }
            catch (Exception ex)
            {
                Console.WriteLine($"Listener exception: {ex}");
            }
        }

        public void Stop()
        {
            _cts.Cancel();
            try { _listener.Stop(); } catch { }
            foreach (var kv in _onlineClients)
            {
                kv.Value.Disconnect();
            }

            FileService.DisposeAll();
        }

        public bool AddOnlineClient(string clientId, ClientHandler handler)
        {
            if (_onlineClients.TryAdd(clientId, handler))
            {
                BroadcastOnlineUsers();
                return true;
            }
            return false;
        }

        public void RemoveOnlineClient(string clientId)
        {
            ClientHandler removed;
            if (_onlineClients.TryRemove(clientId, out removed))
            {
                BroadcastOnlineUsers();
            }
        }

        // Gửi Packet tới tất cả client (trừ sender nếu senderId != null)
        public void Broadcast(Packet p, string senderId = null)
        {
            foreach (var kv in _onlineClients)
            {
                if (!string.IsNullOrEmpty(senderId) && kv.Key.Equals(senderId, StringComparison.OrdinalIgnoreCase))
                    continue;

                _ = kv.Value.SendPacketAsync(p); // best-effort
            }

            if (p.Type == PacketType.Message)
            {
                try
                {
                    // Deserialize message for logging
                    var serializer = new System.Runtime.Serialization.Json.DataContractJsonSerializer(typeof(MessageDTO));
                    using (var ms = new System.IO.MemoryStream(System.Text.Encoding.UTF8.GetBytes(p.Payload ?? "")))
                    {
                        var msg = serializer.ReadObject(ms) as MessageDTO;
                        if (msg != null)
                        {
                            Console.WriteLine($"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] Broadcast message from {msg.SenderId}.");
                        }
                    }
                }
                catch { /* ignore logging errors */ }
            }
        }

        // Gửi danh sách user online cho tất cả client
        public void BroadcastOnlineUsers()
        {
            var users = new System.Collections.Generic.List<string>(_onlineClients.Keys);
            var serializer = new System.Runtime.Serialization.Json.DataContractJsonSerializer(typeof(System.Collections.Generic.List<string>));
            string payload;
            using (var ms = new System.IO.MemoryStream())
            {
                serializer.WriteObject(ms, users);
                payload = System.Text.Encoding.UTF8.GetString(ms.ToArray());
            }

            var p = new Packet
            {
                Type = PacketType.Status,
                Payload = payload
            };

            Broadcast(p);
        }

        // Lấy handler theo id
        public bool TryGetHandler(string clientId, out ClientHandler handler)
        {
            return _onlineClients.TryGetValue(clientId, out handler);
        }
    }
}