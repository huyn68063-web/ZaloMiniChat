using System;
using System.IO;
using System.Net.Sockets;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ZaloMini.Client.Models;

namespace ZaloMini.Server
{
    public class ClientHandler
    {
        private readonly TcpClient _client;
        private readonly NetworkStream _stream;
        private readonly ZaloServer _server;
        private readonly CancellationTokenSource _cts = new CancellationTokenSource();

        // Client identity (username) once logged in
        public string ClientId { get; private set; }

        public ClientHandler(TcpClient client, ZaloServer server)
        {
            _client = client;
            _server = server;
            _stream = client.GetStream();
        }

        public async Task RunAsync()
        {
            try
            {
                // Vòng lặp đọc packet: mỗi packet có 4-byte length prefix (Int32, little-endian) theo sau payload JSON
                // Giải thích:
                // - Đọc chính xác 4 byte đầu để biết độ dài dữ liệu.
                // - Sau đó đọc đủ `length` byte cho payload JSON.
                // - Sử dụng DataContractJsonSerializer để deserialize thành `Packet`.
                while (!_cts.IsCancellationRequested)
                {
                    // đọc 4 byte header
                    var header = await ReadExactAsync(4);
                    if (header == null) break;

                    int payloadLen = BitConverter.ToInt32(header, 0); // little-endian
                    if (payloadLen <= 0) break;

                    var payloadBytes = await ReadExactAsync(payloadLen);
                    if (payloadBytes == null) break;

                    var json = Encoding.UTF8.GetString(payloadBytes);

                    // Deserialize Packet
                    Packet packet;
                    var ser = new DataContractJsonSerializer(typeof(Packet));
                    using (var ms = new MemoryStream(Encoding.UTF8.GetBytes(json)))
                    {
                        packet = ser.ReadObject(ms) as Packet;
                    }

                    if (packet == null) continue;

                    // Delegate xử lý
                    await PacketProcessor.ProcessPacketAsync(packet, this, _server);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ClientHandler exception for {ClientId ?? _client.Client.RemoteEndPoint.ToString()}: {ex.Message}");
            }
            finally
            {
                Disconnect();
            }
        }

        // Gửi Packet: serialize bằng DataContractJsonSerializer rồi viết 4-byte length + payload
        public async Task SendPacketAsync(Packet p)
        {
            try
            {
                var ser = new DataContractJsonSerializer(typeof(Packet));
                using (var ms = new MemoryStream())
                {
                    ser.WriteObject(ms, p);
                    var payload = ms.ToArray();
                    var len = BitConverter.GetBytes(payload.Length); // 4-byte length prefix (little-endian)

                    // Viết header rồi payload
                    await _stream.WriteAsync(len, 0, len.Length);
                    await _stream.WriteAsync(payload, 0, payload.Length);
                    await _stream.FlushAsync();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"SendPacketAsync error to {ClientId}: {ex.Message}");
            }
        }

        // Đọc chính xác `count` byte từ stream; trả về null nếu EOF/đóng kết nối
        private async Task<byte[]> ReadExactAsync(int count)
        {
            var buffer = new byte[count];
            int offset = 0;
            while (offset < count)
            {
                int read = 0;
                try
                {
                    read = await _stream.ReadAsync(buffer, offset, count - offset, _cts.Token);
                }
                catch
                {
                    return null;
                }

                if (read == 0) // remote closed
                    return null;

                offset += read;
            }
            return buffer;
        }

        public void SetClientId(string clientId)
        {
            ClientId = clientId;
            _server.AddOnlineClient(clientId, this);
        }

        public void Disconnect()
        {
            if (!string.IsNullOrEmpty(ClientId))
            {
                _server.RemoveOnlineClient(ClientId);
            }

            try { _cts.Cancel(); } catch { }
            try { _stream.Close(); } catch { }
            try { _client.Close(); } catch { }
        }
    }
}