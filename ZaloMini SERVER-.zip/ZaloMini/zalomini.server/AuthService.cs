using System;
using System.IO;
using System.Threading.Tasks;
using ZaloMini.Client.Models;

namespace ZaloMini.Server.Services
{
    public class AuthService
    {
        private readonly string _userFile;

        public AuthService(string userFile = null)
        {
            _userFile = userFile ?? Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "users.txt");
            if (!File.Exists(_userFile))
                File.WriteAllText(_userFile, string.Empty);
        }

        // Đơn giản: file users.txt từng dòng "username:password"
        public async Task<LoginResult> ValidateUserAsync(string username, string password)
        {
            try
            {
                var lines = await File.ReadAllLinesAsync(_userFile);
                foreach (var line in lines)
                {
                    var parts = line.Split(new[] { ':' }, 2);
                    if (parts.Length != 2) continue;
                    if (parts[0].Equals(username, StringComparison.OrdinalIgnoreCase) &&
                        parts[1] == password)
                    {
                        return new LoginResult
                        {
                            IsSuccess = true,
                            UserInfo = new UserInfo { Id = username, DisplayName = username }
                        };
                    }
                }

                return new LoginResult { IsSuccess = false, ErrorMessage = "Invalid username or password" };
            }
            catch (Exception ex)
            {
                return new LoginResult { IsSuccess = false, ErrorMessage = $"Auth error: {ex.Message}" };
            }
        }

        public async Task<LoginResult> RegisterUserAsync(string username, string password)
        {
            try
            {
                var lines = await File.ReadAllLinesAsync(_userFile);
                foreach (var line in lines)
                {
                    var parts = line.Split(new[] { ':' }, 2);
                    if (parts.Length != 2) continue;
                    if (parts[0].Equals(username, StringComparison.OrdinalIgnoreCase))
                        return new LoginResult { IsSuccess = false, ErrorMessage = "User already exists" };
                }

                var addLine = $"{username}:{password}{Environment.NewLine}";
                await File.AppendAllTextAsync(_userFile, addLine);
                return new LoginResult { IsSuccess = true, UserInfo = new UserInfo { Id = username, DisplayName = username } };
            }
            catch (Exception ex)
            {
                return new LoginResult { IsSuccess = false, ErrorMessage = ex.Message };
            }
        }
    }
}