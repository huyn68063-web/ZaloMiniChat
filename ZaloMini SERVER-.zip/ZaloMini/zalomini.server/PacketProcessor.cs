using System;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using ZaloMini.Client.Models;
using ZaloMini.Server.Services;

namespace ZaloMini.Server
{
    public static class PacketProcessor
    {
        // Xử lý Packet chính
        public static async Task ProcessPacketAsync(Packet packet, ClientHandler handler, ZaloServer server)
        {
            switch (packet.Type)
            {
                case PacketType.Login:
                    await HandleLogin(packet, handler, server);
                    break;

                case PacketType.Logout:
                    HandleLogout(packet, handler, server);
                    break;

                case PacketType.Message:
                    HandleMessage(packet, handler, server);
                    break;

                case PacketType.Status:
                    // Có thể dùng để truyền ACK cho file chunks hoặc status messages
                    await HandleStatus(packet, handler, server);
                    break;

                default:
                    // Thêm hỗ trợ cho các File actions dựa trên nội dung payload
                    await HandlePotentialFilePacket(packet, handler, server);
                    break;
            }
        }

        private static async Task HandleLogin(Packet packet, ClientHandler handler, ZaloServer server)
        {
            try
            {
                var ser = new DataContractJsonSerializer(typeof(LoginRequest));
                LoginRequest req;
                using (var ms = new MemoryStream(Encoding.UTF8.GetBytes(packet.Payload ?? "")))
                {
                    req = ser.ReadObject(ms) as LoginRequest;
                }

                var auth = server.AuthService;
                var result = await auth.ValidateUserAsync(req.Username, req.Password);

                // Nếu đăng nhập thành công, gán ClientId và thêm vào danh sách online
                if (result.IsSuccess)
                {
                    handler.SetClientId(req.Username);
                }

                var serResult = new DataContractJsonSerializer(typeof(LoginResult));
                string payload;
                using (var ms = new MemoryStream())
                {
                    serResult.WriteObject(ms, result);
                    payload = Encoding.UTF8.GetString(ms.ToArray());
                }

                var resp = new Packet
                {
                    Type = PacketType.Login,
                    Payload = payload,
                    RequestId = packet.RequestId
                };

                await handler.SendPacketAsync(resp);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"HandleLogin error: {ex}");
            }
        }

        private static void HandleLogout(Packet packet, ClientHandler handler, ZaloServer server)
        {
            handler?.Disconnect();
        }

        private static void HandleMessage(Packet packet, ClientHandler handler, ZaloServer server)
        {
            // Forward message to everyone except sender
            server.Broadcast(packet, handler.ClientId);
        }

        private static async Task HandleStatus(Packet packet, ClientHandler handler, ZaloServer server)
        {
            // Dùng làm ACK cho file chunk truyền Stop-and-Wait:
            // Khi server nhận FILE_CHUNK và viết xong, server gửi lại Packet với Payload = "OK".
            // Client chờ nhận OK rồi mới gửi chunk tiếp theo.
            // Ở đây, nếu client gửi một status-type payload, ta có thể log hoặc ignore.
            await Task.CompletedTask;
        }

        // Nếu PacketType không chỉ rõ file, ta inspect payload JSON để xem có field "Action" cho FILE_META/FILE_CHUNK/FILE_END
        private static async Task HandlePotentialFilePacket(Packet packet, ClientHandler handler, ZaloServer server)
        {
            try
            {
                // parse payload into a small wrapper to detect Action
                var ser = new DataContractJsonSerializer(typeof(FileActionWrapper));
                FileActionWrapper wrapper;
                using (var ms = new MemoryStream(Encoding.UTF8.GetBytes(packet.Payload ?? "")))
                {
                    wrapper = ser.ReadObject(ms) as FileActionWrapper;
                }

                if (wrapper == null || string.IsNullOrEmpty(wrapper.Action))
                    return;

                var fileService = server.FileService;
                switch (wrapper.Action)
                {
                    case "FILE_META":
                        // wrapper.Payload contains file metadata (FileName, RequestId, TotalSize)
                        var metaSer = new DataContractJsonSerializer(typeof(FileMetaDTO));
                        FileMetaDTO meta;
                        using (var ms = new MemoryStream(Encoding.UTF8.GetBytes(packet.Payload)))
                        {
                            meta = metaSer.ReadObject(ms) as FileMetaDTO;
                        }

                        fileService.CreateFileStream(meta.RequestId, meta.FileName);
                        Console.WriteLine($"[ {DateTime.Now:HH:mm:ss} ] Begin receiving file {meta.FileName} from {handler.ClientId}");
                        break;

                    case "FILE_CHUNK":
                        // wrapper.Payload contains chunk base64 data and offset
                        var chunkSer = new DataContractJsonSerializer(typeof(FileChunkDTO));
                        FileChunkDTO chunk;
                        using (var ms = new MemoryStream(Encoding.UTF8.GetBytes(packet.Payload)))
                        {
                            chunk = chunkSer.ReadObject(ms) as FileChunkDTO;
                        }

                        // Ghi chunk vào disk
                        fileService.WriteChunk(chunk.RequestId, Convert.FromBase64String(chunk.Base64Data));

                        // Stop-and-Wait: gửi ACK "OK" để client biết có thể gửi chunk kế tiếp
                        var ack = new Packet
                        {
                            Type = PacketType.Status,
                            Payload = "\"OK\"",
                            RequestId = packet.RequestId
                        };
                        await handler.SendPacketAsync(ack);
                        break;

                    case "FILE_END":
                        var endSer = new DataContractJsonSerializer(typeof(FileEndDTO));
                        FileEndDTO end;
                        using (var ms = new MemoryStream(Encoding.UTF8.GetBytes(packet.Payload)))
                        {
                            end = endSer.ReadObject(ms) as FileEndDTO;
                        }

                        fileService.CloseFileStream(end.RequestId);
                        Console.WriteLine($"[ {DateTime.Now:HH:mm:ss} ] Finished receiving file {end.FileName} from {handler.ClientId}");

                        // Tùy chọn: thông báo cho mọi client
                        var notice = new Packet
                        {
                            Type = PacketType.Status,
                            Payload = $"\"FileReceived:{end.FileName}\""
                        };
                        server.Broadcast(notice);
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"HandlePotentialFilePacket error: {ex.Message}");
            }
        }

        // Helper DTOs for detecting file action (kept minimal)
        private class FileActionWrapper
        {
            public string Action { get; set; }
        }
    }

    // DTOs cho File transfer (dạng JSON)
    public class FileMetaDTO
    {
        public string Action { get; set; } = "FILE_META";
        public string RequestId { get; set; }
        public string FileName { get; set; }
        public long TotalSize { get; set; }
    }

    public class FileChunkDTO
    {
        public string Action { get; set; } = "FILE_CHUNK";
        public string RequestId { get; set; }
        public int ChunkIndex { get; set; }
        public string Base64Data { get; set; } // chunk data encoded base64
    }

    public class FileEndDTO
    {
        public string Action { get; set; } = "FILE_END";
        public string RequestId { get; set; }
        public string FileName { get; set; }
    }
}