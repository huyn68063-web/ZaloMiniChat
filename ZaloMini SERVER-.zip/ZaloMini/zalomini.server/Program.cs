﻿using System;
using System.Threading.Tasks;

namespace ZaloMini.Server
{
    class Program
    {
        static async Task Main(string[] args)
        {
            var server = new ZaloServer(port: 9000);
            Console.CancelKeyPress += (s, e) =>
            {
                Console.WriteLine("Shutting down...");
                server.Stop();
            };

            await server.StartAsync();
        }
    }
}