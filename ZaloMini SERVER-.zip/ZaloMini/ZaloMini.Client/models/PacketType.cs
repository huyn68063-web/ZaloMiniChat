using System.Runtime.Serialization;

namespace ZaloMini.Client.Models
{
    [DataContract]
    public enum PacketType
    {
        Login = 0,
        Message = 1,
        Status = 2,
        Logout = 3
    }
}
