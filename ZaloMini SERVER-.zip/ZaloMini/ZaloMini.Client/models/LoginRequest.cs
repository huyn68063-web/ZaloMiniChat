using System.Runtime.Serialization;

namespace ZaloMini.Client.Models
{
    [DataContract]
    public class LoginRequest
    {
        [DataMember]
        public string Username { get; set; }

        [DataMember(EmitDefaultValue = false)]
        public string Password { get; set; }
    }
}