using System;
using System.IO;
using System.Net.Sockets;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using System.Threading;
using ZaloMini.Client.Models;
using ZaloMini.Client.Network;

namespace ZaloMini.Client.Network
{
    public class NetworkClient : INetworkClient
    {
        private const int HEADER_SIZE = 4;
        private const int BUFFERSIZE = 1024 * 1000; // 1MB per requirement (Stop-and-Wait chunk size)

        private TcpClient _tcp;
        private NetworkStream _stream;
        private CancellationTokenSource _cts;
        private readonly SemaphoreSlim _sendLock = new SemaphoreSlim(1, 1);
        private readonly ConcurrentDictionary<string, TaskCompletionSource<string>> _pendingAcks =
            new ConcurrentDictionary<string, TaskCompletionSource<string>>(StringComparer.OrdinalIgnoreCase);

        // Singleton instance
        private static readonly Lazy<NetworkClient> _lazy = new Lazy<NetworkClient>(() => new NetworkClient());
        public static NetworkClient Instance => _lazy.Value;

        public bool IsConnected { get; private set; }

        public event Action<Packet> OnPacketReceived;

        // Optional: notify UI when disconnected
        public event Action OnDisconnected;

        private NetworkClient() { }

        public async Task ConnectAsync(string host, int port)
        {
            if (string.IsNullOrWhiteSpace(host))
                host = "127.0.0.1";
            if (port <= 0)
                port = 9000;

            _tcp = new TcpClient();
            await _tcp.ConnectAsync(host, port).ConfigureAwait(false);
            _stream = _tcp.GetStream();
            IsConnected = true;

            _cts = new CancellationTokenSource();
            _ = Task.Run(() => ReceiveLoopAsync(_cts.Token));
        }

        public async Task DisconnectAsync()
        {
            try
            {
                _cts?.Cancel();
            }
            catch { }

            try { _stream?.Close(); } catch { }
            try { _tcp?.Close(); } catch { }

            IsConnected = false;
            try { OnDisconnected?.Invoke(); } catch { }

            await Task.CompletedTask;
        }

        public void Dispose()
        {
            _ = DisconnectAsync();
        }

        // Gửi Packet theo giao thức: 4-byte length prefix (Int32 little-endian) + payload JSON
        public async Task SendPacketAsync(Packet packet)
        {
            if (!IsConnected || _stream == null) throw new InvalidOperationException("Not connected");

            var ser = new DataContractJsonSerializer(typeof(Packet));
            byte[] body;
            using (var ms = new MemoryStream())
            {
                ser.WriteObject(ms, packet);
                body = ms.ToArray();
            }

            var header = BitConverter.GetBytes(body.Length); // 4-byte little-endian

            await _sendLock.WaitAsync().ConfigureAwait(false);
            try
            {
                // Viết header rồi payload theo thứ tự
                await _stream.WriteAsync(header, 0, header.Length).ConfigureAwait(false);
                await _stream.WriteAsync(body, 0, body.Length).ConfigureAwait(false);
                await _stream.FlushAsync().ConfigureAwait(false);
            }
            finally
            {
                _sendLock.Release();
            }
        }

        // Gửi file theo Stop-and-Wait: sau mỗi chunk (1MB) chờ ACK "OK" từ server trước khi gửi tiếp
        public async Task SendFileAsync(string filePath, string targetFileName = null, CancellationToken ct = default)
        {
            if (!IsConnected) throw new InvalidOperationException("Not connected");
            if (!File.Exists(filePath)) throw new FileNotFoundException(filePath);

            var requestId = Guid.NewGuid().ToString("N");
            targetFileName = string.IsNullOrWhiteSpace(targetFileName) ? Path.GetFileName(filePath) : targetFileName;
            var fileInfo = new FileInfo(filePath);

            // DTOs used only locally to build JSON payloads
            var meta = new
            {
                Action = "FILE_META",
                RequestId = requestId,
                FileName = targetFileName,
                TotalSize = fileInfo.Length
            };

            var metaPayload = SerializeToJson(meta);
            var metaPacket = new Packet { Type = PacketType.Status, Payload = metaPayload, RequestId = requestId };
            await SendPacketAsync(metaPacket).ConfigureAwait(false);

            // Open file and send chunks
            using (var fs = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                var buffer = new byte[BUFFERSIZE];
                int bytesRead;
                int chunkIndex = 0;

                while ((bytesRead = await fs.ReadAsync(buffer, 0, buffer.Length, ct).ConfigureAwait(false)) > 0)
                {
                    chunkIndex++;

                    // Prepare chunk DTO
                    var base64 = Convert.ToBase64String(buffer, 0, bytesRead);
                    var chunkDto = new
                    {
                        Action = "FILE_CHUNK",
                        RequestId = requestId,
                        ChunkIndex = chunkIndex,
                        Base64Data = base64
                    };

                    var chunkPayload = SerializeToJson(chunkDto);
                    var chunkPacket = new Packet { Type = PacketType.Status, Payload = chunkPayload, RequestId = requestId };

                    // Prepare TaskCompletionSource to wait for ACK from server for this requestId
                    var tcs = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
                    if (!_pendingAcks.TryAdd(requestId, tcs))
                    {
                        // If previously exists, replace it
                        _pendingAcks[requestId] = tcs;
                    }

                    // Send chunk
                    await SendPacketAsync(chunkPacket).ConfigureAwait(false);

                    // Wait for server ACK "OK" (with same RequestId)
                    var completedTask = await Task.WhenAny(tcs.Task, Task.Delay(TimeSpan.FromSeconds(30), ct)).ConfigureAwait(false);
                    if (completedTask != tcs.Task)
                    {
                        _pendingAcks.TryRemove(requestId, out _);
                        throw new TimeoutException("Timeout waiting for server ACK for file chunk.");
                    }

                    var ackVal = await tcs.Task.ConfigureAwait(false);
                    _pendingAcks.TryRemove(requestId, out _);

                    // ensure ACK is OK (server may send quoted JSON string "\"OK\"")
                    var ackTrim = (ackVal ?? "").Trim().Trim('\"');
                    if (!string.Equals(ackTrim, "OK", StringComparison.OrdinalIgnoreCase))
                    {
                        throw new InvalidOperationException("Server returned non-OK ACK for file chunk: " + ackVal);
                    }
                }
            }

            // Send FILE_END
            var endDto = new
            {
                Action = "FILE_END",
                RequestId = requestId,
                FileName = targetFileName
            };
            var endPayload = SerializeToJson(endDto);
            var endPacket = new Packet { Type = PacketType.Status, Payload = endPayload, RequestId = requestId };
            await SendPacketAsync(endPacket).ConfigureAwait(false);
        }

        // Internal receive loop: đọc 4-byte length header rồi đọc payload JSON tương ứng,
        // Deserialize thành Packet và kích hoạt event.
        // Đồng thời nếu là ACK (PacketType.Status với payload "OK") sẽ hoàn tất TaskCompletionSource tương ứng.
        private async Task ReceiveLoopAsync(CancellationToken ct)
        {
            try
            {
                var header = new byte[HEADER_SIZE];
                while (!ct.IsCancellationRequested && IsConnected)
                {
                    var read = await ReadExactAsync(_stream, header, 0, HEADER_SIZE, ct).ConfigureAwait(false);
                    if (read == 0) break;

                    int len = BitConverter.ToInt32(header, 0);
                    if (len <= 0) continue;

                    var body = new byte[len];
                    read = await ReadExactAsync(_stream, body, 0, len, ct).ConfigureAwait(false);
                    if (read == 0) break;

                    Packet packet = null;
                    try
                    {
                        var ser = new DataContractJsonSerializer(typeof(Packet));
                        using (var ms = new MemoryStream(body))
                        {
                            packet = ser.ReadObject(ms) as Packet;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Failed to deserialize Packet: " + ex.Message);
                        continue;
                    }

                    // Nếu packet là ACK cho file chunk, hoàn tất TCS dựa trên RequestId
                    if (packet != null && packet.Type == PacketType.Status && !string.IsNullOrEmpty(packet.RequestId))
                    {
                        var payloadText = (packet.Payload ?? "").Trim();
                        // payload may be JSON string "\"OK\"" or plain OK
                        var payloadUnquoted = payloadText;
                        if (payloadUnquoted.Length >= 2 && payloadUnquoted.StartsWith("\"") && payloadUnquoted.EndsWith("\""))
                            payloadUnquoted = payloadUnquoted.Substring(1, payloadUnquoted.Length - 2);

                        if (_pendingAcks.TryGetValue(packet.RequestId, out var tcs))
                        {
                            // set result (complete ack wait)
                            tcs.TrySetResult(payloadUnquoted);
                        }
                    }

                    // Raise general packet event for UI/logic
                    try
                    {
                        if (packet != null)
                            OnPacketReceived?.Invoke(packet);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("OnPacketReceived handler error: " + ex.Message);
                    }
                }
            }
            catch (OperationCanceledException) { }
            catch (Exception ex)
            {
                Console.WriteLine("ReceiveLoop error: " + ex.Message);
            }
            finally
            {
                IsConnected = false;
                try { OnDisconnected?.Invoke(); } catch { }
                await DisconnectAsync().ConfigureAwait(false);
            }
        }

        // Helper: read exact count bytes or return 0 if remote closed
        private static async Task<int> ReadExactAsync(Stream stream, byte[] buffer, int offset, int count, CancellationToken ct)
        {
            int total = 0;
            while (total < count)
            {
                int read = await stream.ReadAsync(buffer, offset + total, count - total, ct).ConfigureAwait(false);
                if (read == 0) return 0;
                total += read;
            }
            return total;
        }

        private static string SerializeToJson<T>(T obj)
        {
            var ser = new DataContractJsonSerializer(typeof(T));
            using (var ms = new MemoryStream())
            {
                ser.WriteObject(ms, obj);
                return Encoding.UTF8.GetString(ms.ToArray());
            }
        }
    }
}